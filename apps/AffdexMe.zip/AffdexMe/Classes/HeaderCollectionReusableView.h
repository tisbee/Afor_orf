//
//  HeaderCollectionReusableView.h
//  AffdexMe
//
//  Created by boisy on 8/29/15.
//  Copyright (c) 2015 Affectiva. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HeaderCollectionReusableView : UICollectionReusableView

@property (weak) IBOutlet UILabel *label;

@end
